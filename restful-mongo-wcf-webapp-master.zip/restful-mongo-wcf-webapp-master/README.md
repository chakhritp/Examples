#RESTFul
A very simple MongoDB integration with WCF, a complete CRUD with simple javascript 
<h3>Requirements</h3>
<ul>
<li>local mongodb server runnning.</li>
</ul>
